import os
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from datetime import datetime

BASE_URL = "https://www.saucedemo.com/"

REPORTS_DIR = os.path.join(os.getcwd(), "reports")
SCREENSHOT_DIR = os.path.join(REPORTS_DIR, "screenshots")
EXTRACT_DIR = os.path.join(REPORTS_DIR, "extracted")

os.makedirs(SCREENSHOT_DIR, exist_ok=True)
os.makedirs(EXTRACT_DIR, exist_ok=True)

def _timestamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def pytest_addoption(parser):
    parser.addoption("--headless", action="store_true", default=True, help="Run browser in headless mode")

@pytest.fixture(scope="session")
def base_url():
    return BASE_URL

@pytest.fixture(scope="function")
def driver(request):
    headless = request.config.getoption("--headless")
    opts = Options()
    if headless:
        # minimal headless profile
        opts.add_argument("--headless=new")
        opts.add_argument("--disable-gpu")
    opts.add_argument("--window-size=1920,1080")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--lang=en-US")
    # Create driver via webdriver-manager
    service = ChromeService(ChromeDriverManager().install())
    drv = webdriver.Chrome(service=service, options=opts)
    drv.implicitly_wait(5)
    yield drv
    try:
        drv.quit()
    except Exception:
        pass

# take screenshot on failure and attach file path to report
@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    # execute all other hooks to get the report object
    outcome = yield
    rep = outcome.get_result()
    if rep.when == "call" and rep.failed:
        driver_fixture = item.funcargs.get("driver", None)
        if driver_fixture:
            fname = f"failure_{item.name}_{_timestamp()}.png"
            path = os.path.join(SCREENSHOT_DIR, fname)
            try:
                driver_fixture.save_screenshot(path)
                # add path to report longrepr so it will be visible
                if hasattr(rep, "longrepr"):
                    rep.longrepr = f"{rep.longrepr}\nScreenshot: {path}"
            except Exception:
                pass
