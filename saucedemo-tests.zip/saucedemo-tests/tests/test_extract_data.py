import pytest
import json
import os
from pages import LoginPage, InventoryPage

EXTRACT_FILE = os.path.join("reports", "extracted", "inventory_data.json")

@pytest.mark.extract
def test_extract_inventory_and_logout(driver, base_url):
    login = LoginPage(driver)
    login.open()
    login.login("standard_user", "secret_sauce")

    inv = InventoryPage(driver)
    assert inv.is_logo_present(), "Must be on inventory page before extraction"

    # extract data
    data = inv.get_inventory_data()
    # write JSON
    os.makedirs(os.path.dirname(EXTRACT_FILE), exist_ok=True)
    with open(EXTRACT_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

    assert os.path.exists(EXTRACT_FILE), "Extracted file must exist"

    # logout and verify on login page
    inv.logout()
    # after logout, login button should be visible
    from selenium.webdriver.common.by import By
    login_button_present = len(driver.find_elements(By.ID, "login-button")) > 0
    assert login_button_present, "After logout, login button should be visible (on login page)"

    driver.save_screenshot("reports/screenshots/extract_inventory.png")
