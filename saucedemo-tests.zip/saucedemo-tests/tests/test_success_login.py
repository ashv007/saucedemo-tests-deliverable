import pytest
from pages import LoginPage, InventoryPage

@pytest.mark.success
def test_successful_login_shows_logo(driver, base_url):
    login = LoginPage(driver)
    login.open()
    # Standard user credentials per instructions
    login.login("standard_user", "secret_sauce")
    inv = InventoryPage(driver)
    assert inv.is_logo_present(), "App logo should be present on inventory page"
    # take screenshot for evidence (saved in reports/screenshots)
    driver.save_screenshot(f"reports/screenshots/success_login_{pytest.__version__}.png")
