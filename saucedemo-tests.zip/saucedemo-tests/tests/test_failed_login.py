import pytest
from pages import LoginPage

@pytest.mark.failed
def test_locked_out_user_shows_error(driver, base_url):
    login = LoginPage(driver)
    login.open()
    login.login("locked_out_user", "secret_sauce")
    err = login.get_error_text()
    assert "Sorry, this user has been locked out" in err or "locked out" in err.lower() or "banned" in err.lower(), f"Expected locked out message in: {err}"
    # screenshot
    driver.save_screenshot("reports/screenshots/failed_login_lockedout.png")
