from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class LoginPage:
    URL = "https://www.saucedemo.com/"
    username_input = (By.ID, "user-name")
    password_input = (By.ID, "password")
    login_button = (By.ID, "login-button")
    error_container = (By.CSS_SELECTOR, "h3[data-test='error']")

    def __init__(self, driver):
        self.driver = driver

    def open(self):
        self.driver.get(self.URL)

    def login(self, username, password):
        WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(self.username_input)).clear()
        self.driver.find_element(*self.username_input).send_keys(username)
        self.driver.find_element(*self.password_input).clear()
        self.driver.find_element(*self.password_input).send_keys(password)
        self.driver.find_element(*self.login_button).click()

    def get_error_text(self):
        return WebDriverWait(self.driver, 5).until(EC.visibility_of_element_located(self.error_container)).text

class InventoryPage:
    app_logo = (By.CLASS_NAME, "app_logo")
    inventory_items = (By.CSS_SELECTOR, ".inventory_item")
    menu_button = (By.ID, "react-burger-menu-btn")
    logout_link = (By.ID, "logout_sidebar_link")

    def __init__(self, driver):
        self.driver = driver

    def is_logo_present(self):
        return len(self.driver.find_elements(*self.app_logo)) > 0

    def get_inventory_data(self):
        # returns list of dicts with name and price
        items = self.driver.find_elements(*self.inventory_items)
        data = []
        for item in items:
            name = item.find_element(By.CLASS_NAME, "inventory_item_name").text
            desc = item.find_element(By.CLASS_NAME, "inventory_item_desc").text
            price = item.find_element(By.CLASS_NAME, "inventory_item_price").text
            data.append({"name": name, "description": desc, "price": price})
        return data

    def logout(self):
        self.driver.find_element(*self.menu_button).click()
        WebDriverWait(self.driver, 5).until(EC.visibility_of_element_located(self.logout_link)).click()
